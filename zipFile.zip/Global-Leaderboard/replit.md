# i2u.ai Global Leaderboard & Registration System

## Overview

This is a full-stack web application for a global startup ecosystem leaderboard and registration system. The platform enables startups, investors, and ecosystem participants to register, get ranked on a global leaderboard, track activities, manage referrals, and handle wallet/earnings. The application serves the i2u.ai platform with the tagline "Ideas to Unicorns through AI."

Key features include:
- Multi-step user registration with role selection and payment integration
- Global leaderboard with filtering by country and sector
- Activity time tracking system
- Referral program with dual-currency earnings (INR/USD)
- Wallet management for referral earnings
- Admin dashboard for system oversight

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack Query (React Query) for server state
- **Styling**: Tailwind CSS v4 with CSS variables for theming
- **UI Components**: shadcn/ui component library (New York style) with Radix UI primitives
- **Animations**: Framer Motion for page transitions and micro-interactions
- **Build Tool**: Vite with custom plugins for meta images and Replit integration

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript compiled with tsx
- **API Pattern**: REST API with JSON responses
- **Structure**: Single server entry point with route registration pattern

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL (Replit's native PostgreSQL integration via DATABASE_URL)
- **Schema Location**: `shared/schema.ts` - shared between frontend and backend
- **Migrations**: Drizzle Kit for database migrations (`drizzle-kit push`)

### Key Design Decisions

1. **Monorepo Structure**: Client code in `client/`, server in `server/`, shared types in `shared/`
   - Enables type sharing between frontend and backend
   - Single deployment unit simplifies hosting

2. **Schema-First Approach**: Database schema defined with Drizzle, then Zod schemas generated via drizzle-zod for validation
   - Single source of truth for data types
   - Automatic type inference across the stack

3. **Dual Currency Support**: System handles both INR and USD for international users
   - Separate wallet balances per currency
   - Payment integration designed for Stripe (USD) and Cashfree (INR)

4. **Privacy Controls**: Users can control how their data appears on leaderboards
   - Display preferences: real_name, username, anonymous, fancy_username
   - Activity privacy: private, anonymous_aggregate, public_leaderboard

5. **Theme System**: Light/dark mode with CSS variables
   - Primary teal color (#218089) for brand consistency
   - System-level theme switching via root class

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connected via `DATABASE_URL` environment variable
- **connect-pg-simple**: Session storage in PostgreSQL

### Payment Processing (Planned)
- **Stripe**: USD payment processing (test mode integration ready)
- **Cashfree**: INR payment processing for Indian users (test mode integration ready)

### Frontend Libraries
- **@tanstack/react-query**: Server state management and caching
- **framer-motion**: Animation library
- **react-hook-form + zod**: Form handling with validation
- **date-fns**: Date manipulation
- **lucide-react**: Icon library

### Build & Development
- **Vite**: Development server and production bundler
- **esbuild**: Server-side bundling for production
- **tsx**: TypeScript execution for development

### Replit-Specific
- **@replit/vite-plugin-runtime-error-modal**: Error overlay in development
- **@replit/vite-plugin-cartographer**: Development tooling
- Custom meta images plugin for OpenGraph/Twitter cards with Replit deployment URLs