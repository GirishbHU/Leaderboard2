import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, boolean, timestamp, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const userRoles = ["builder", "investor", "enabler", "startup", "influencer", "professional", "accelerator", "ngo", "vc", "government", "mentor", "service_provider", "angel", "admin"] as const;
export const currencies = ["INR", "USD"] as const;
export const displayPreferences = ["real_name", "username", "anonymous", "fancy_username"] as const;
export const subscriptionTiers = ["Beginner", "Professional", "Advanced", "Pro Max Ultra"] as const;
export const userStatuses = ["verified", "pending"] as const;
export const activityPrivacyOptions = ["private", "anonymous_aggregate", "public_leaderboard"] as const;
export const subscriptionStatuses = ["inactive", "active_preview", "active_sandbox", "active_live"] as const;
export const planTypes = ["free", "preview", "basic", "premium", "enterprise"] as const;

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  username: text("username"),
  password: text("password").notNull(),
  role: text("role").notNull().default("startup"),
  country: text("country").notNull().default("India"),
  sector: text("sector").notNull().default("Fintech"),
  currency: text("currency").notNull().default("INR"),
  displayPreference: text("display_preference").notNull().default("real_name"),
  companyName: text("company_name"),
  startupStage: text("startup_stage"),
  registrationNumber: serial("registration_number"),
  registrationDate: timestamp("registration_date").defaultNow(),
  referralCode: text("referral_code").notNull().unique(),
  referralCount: integer("referral_count").notNull().default(0),
  referralEarningsINR: real("referral_earnings_inr").notNull().default(0),
  referralEarningsUSD: real("referral_earnings_usd").notNull().default(0),
  showEarningsPublicly: boolean("show_earnings_publicly").notNull().default(true),
  activityPrivacy: text("activity_privacy").notNull().default("private"),
  walletINRAvailable: real("wallet_inr_available").notNull().default(0),
  walletINRPending: real("wallet_inr_pending").notNull().default(0),
  walletUSDAvailable: real("wallet_usd_available").notNull().default(0),
  walletUSDPending: real("wallet_usd_pending").notNull().default(0),
  leaderboardRank: integer("leaderboard_rank").notNull().default(0),
  percentile: real("percentile").notNull().default(0),
  subscriptionTier: text("subscription_tier").notNull().default("Beginner"),
  status: text("status").notNull().default("pending"),
  subscriptionStatus: text("subscription_status").notNull().default("inactive"),
  planType: text("plan_type").notNull().default("free"),
});

export const activityTimeTracking = pgTable("activity_time_tracking", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  activityName: text("activity_name").notNull(),
  category: text("category").notNull(),
  timeSpentMinutes: integer("time_spent_minutes").notNull(),
  date: timestamp("date").defaultNow(),
  description: text("description"),
});

export const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  referrerId: varchar("referrer_id").references(() => users.id),
  referredId: varchar("referred_id").references(() => users.id),
  earningsINR: real("earnings_inr").notNull().default(0),
  earningsUSD: real("earnings_usd").notNull().default(0),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const walletTransactions = pgTable("wallet_transactions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  type: text("type").notNull(),
  amount: real("amount").notNull(),
  currency: text("currency").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  registrationNumber: true,
  registrationDate: true,
});

export const insertActivitySchema = createInsertSchema(activityTimeTracking).omit({
  id: true,
  date: true,
});

export const insertReferralSchema = createInsertSchema(referrals).omit({
  id: true,
  createdAt: true,
});

export const insertTransactionSchema = createInsertSchema(walletTransactions).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activityTimeTracking.$inferSelect;
export type InsertReferral = z.infer<typeof insertReferralSchema>;
export type Referral = typeof referrals.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof walletTransactions.$inferSelect;

export const blogCategories = ["AI", "Technology", "Leadership", "Business Strategy"] as const;

export const blogArticles = pgTable("blog_articles", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  excerpt: text("excerpt"),
  content: text("content"),
  category: text("category").notNull().default("AI"),
  linkedinUrl: text("linkedin_url"),
  publishedDate: timestamp("published_date").defaultNow(),
  featured: boolean("featured").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const insertBlogArticleSchema = createInsertSchema(blogArticles).omit({
  id: true,
});

export type InsertBlogArticle = z.infer<typeof insertBlogArticleSchema>;
export type BlogArticle = typeof blogArticles.$inferSelect;
