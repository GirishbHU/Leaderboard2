import { AlertTriangle, Info } from "lucide-react";
import { useAuth } from "@/lib/authContext";

export function PreviewBanner() {
  const { isPreviewMode, isAuthenticated } = useAuth();
  
  if (!isAuthenticated || !isPreviewMode) {
    return null;
  }

  return (
    <div className="bg-amber-500/10 border-b border-amber-500/20 px-4 py-2">
      <div className="container mx-auto flex items-center justify-center gap-2 text-sm">
        <AlertTriangle className="h-4 w-4 text-amber-600" />
        <span className="text-amber-700 dark:text-amber-400 font-medium">
          Preview Mode
        </span>
        <span className="text-amber-600/80 dark:text-amber-500/80">
          - You are using simulated payments. Data may be reset periodically.
        </span>
        <Info className="h-4 w-4 text-amber-600/60 ml-2" />
      </div>
    </div>
  );
}
