import { useState } from "react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  BookOpen,
  ExternalLink,
  Lightbulb,
  Users,
  Cpu,
  TrendingUp,
  Loader2
} from "lucide-react";
import type { BlogArticle } from "@shared/schema";

const categories = ["All", "AI", "Technology", "Leadership", "Business Strategy"];

const categoryIcons: Record<string, React.ReactNode> = {
  "AI": <Lightbulb className="h-6 w-6" />,
  "Technology": <Cpu className="h-6 w-6" />,
  "Leadership": <Users className="h-6 w-6" />,
  "Business Strategy": <TrendingUp className="h-6 w-6" />
};

export default function Blog() {
  const [selectedCategory, setSelectedCategory] = useState("All");

  const { data: articlesResponse, isLoading } = useQuery<{ data: BlogArticle[]; total: number }>({
    queryKey: ["/api/blog", selectedCategory],
    queryFn: async () => {
      const params = new URLSearchParams();
      params.set("limit", "50");
      if (selectedCategory !== "All") {
        params.set("category", selectedCategory);
      }
      const res = await fetch(`/api/blog?${params.toString()}`);
      return res.json();
    }
  });

  const { data: featuredArticles } = useQuery<BlogArticle[]>({
    queryKey: ["/api/blog/featured"],
    queryFn: async () => {
      const res = await fetch("/api/blog/featured?limit=1");
      return res.json();
    }
  });

  const articles = articlesResponse?.data || [];
  const featuredArticle = featuredArticles?.[0];

  const formatDate = (date: string | Date | null) => {
    if (!date) return "";
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  };

  return (
    <div className="flex flex-col items-center space-y-16 py-8">
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center space-y-6 max-w-4xl px-4"
      >
        <Badge className="bg-primary/10 text-primary hover:bg-primary/20 text-sm py-1 px-4">
          <BookOpen className="w-4 h-4 mr-2" />
          i2u.ai Blog
        </Badge>
        
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
          <span className="text-foreground">Insights for</span>
          <br />
          <span className="text-primary">Tomorrow's Unicorns</span>
        </h1>
        
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Expert insights on AI, technology leadership, and business strategy from our LinkedIn newsletter.
        </p>

        <a 
          href="https://www.linkedin.com/newsletters/i2u-ai-blog-7359775076067467264/" 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 text-primary hover:underline"
        >
          Subscribe on LinkedIn <ExternalLink className="h-4 w-4" />
        </a>
      </motion.section>

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="w-full max-w-6xl px-4"
      >
        <div className="flex flex-wrap gap-2 justify-center mb-8">
          {categories.map((category) => (
            <Badge 
              key={category} 
              variant={selectedCategory === category ? "default" : "outline"}
              className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors"
              onClick={() => setSelectedCategory(category)}
              data-testid={`category-${category.toLowerCase().replace(/\s/g, '-')}`}
            >
              {category}
            </Badge>
          ))}
        </div>
      </motion.section>

      {featuredArticle && (
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="w-full max-w-6xl px-4"
        >
          <Card className="overflow-hidden hover:shadow-xl transition-shadow group">
            <div className="grid md:grid-cols-2">
              <div className="bg-gradient-to-br from-primary/20 to-primary/5 p-8 flex items-center justify-center">
                <div className="text-primary">
                  {categoryIcons[featuredArticle.category] || <Lightbulb className="h-24 w-24" />}
                </div>
              </div>
              <CardContent className="p-8 flex flex-col justify-center">
                <div className="flex items-center gap-2 mb-4">
                  <Badge>{featuredArticle.category}</Badge>
                  <Badge variant="secondary">Featured</Badge>
                </div>
                <h2 className="text-2xl font-bold mb-3 group-hover:text-primary transition-colors">
                  {featuredArticle.title}
                </h2>
                <p className="text-muted-foreground mb-4">{featuredArticle.excerpt}</p>
                <div className="text-sm text-muted-foreground mb-4">
                  {formatDate(featuredArticle.publishedDate)}
                </div>
                {featuredArticle.linkedinUrl && (
                  <a 
                    href={featuredArticle.linkedinUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <Button data-testid="button-read-featured">
                      Read on LinkedIn <ExternalLink className="ml-2 h-4 w-4" />
                    </Button>
                  </a>
                )}
              </CardContent>
            </div>
          </Card>
        </motion.section>
      )}

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="w-full max-w-6xl px-4"
      >
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2">
            {selectedCategory === "All" ? "All Articles" : selectedCategory}
          </h2>
          <p className="text-muted-foreground">
            {articlesResponse?.total || 0} articles from the i2u.ai newsletter
          </p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article) => (
              <a 
                key={article.id} 
                href={article.linkedinUrl || "#"} 
                target="_blank" 
                rel="noopener noreferrer"
                className="block"
              >
                <Card className="h-full hover:shadow-lg transition-shadow group cursor-pointer" data-testid={`blog-card-${article.id}`}>
                  <CardContent className="p-6 flex flex-col h-full">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary mb-4">
                      {categoryIcons[article.category] || <Lightbulb className="h-6 w-6" />}
                    </div>
                    <Badge variant="outline" className="w-fit mb-3">{article.category}</Badge>
                    <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors line-clamp-2">
                      {article.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-3 flex-grow">
                      {article.excerpt}
                    </p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground mt-auto">
                      <span>{formatDate(article.publishedDate)}</span>
                      <span className="flex items-center gap-1 text-primary">
                        Read <ArrowRight className="h-3 w-3" />
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </a>
            ))}
          </div>
        )}
      </motion.section>

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="w-full max-w-4xl px-4"
      >
        <Card className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
          <CardContent className="py-12 text-center">
            <BookOpen className="h-12 w-12 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-4">Subscribe to Our Newsletter</h2>
            <p className="opacity-90 mb-6 max-w-xl mx-auto">
              Get the latest AI insights, leadership profiles, and business strategy content delivered to your LinkedIn feed.
            </p>
            <a 
              href="https://www.linkedin.com/newsletters/i2u-ai-blog-7359775076067467264/" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <Button variant="secondary" size="lg" data-testid="button-subscribe">
                Subscribe on LinkedIn <ExternalLink className="ml-2 h-4 w-4" />
              </Button>
            </a>
          </CardContent>
        </Card>
      </motion.section>
    </div>
  );
}
