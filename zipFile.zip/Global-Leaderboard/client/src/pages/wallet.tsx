import React, { useState } from "react";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { CURRENT_USER } from "@/lib/mockData";
import { Wallet as WalletIcon, Download, Share2, Copy } from "lucide-react";

export default function Wallet() {
  const user = CURRENT_USER;
  
  // Mock transactions
  const transactions = [
    { id: "tx_123456", date: "2025-12-14", type: "Referral Earning", amount: 99.90, currency: "INR", status: "completed" },
    { id: "tx_123457", date: "2025-12-13", type: "Referral Earning", amount: 1.50, currency: "USD", status: "pending" },
    { id: "tx_123458", date: "2025-12-10", type: "Payment (Pro Max Ultra)", amount: -999, currency: "INR", status: "completed" },
    { id: "tx_123459", date: "2025-12-05", type: "Referral Earning", amount: 99.90, currency: "INR", status: "completed" },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Wallet</h1>
          <p className="text-muted-foreground">Manage your earnings and payouts.</p>
        </div>
      </div>

      <Tabs defaultValue="balance" className="w-full">
        <TabsList className="grid w-full grid-cols-3 max-w-md mb-8">
          <TabsTrigger value="balance">Balance</TabsTrigger>
          <TabsTrigger value="referrals">Referrals</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
        </TabsList>

        <TabsContent value="balance" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* INR Wallet */}
            <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 dark:from-green-950/20 dark:to-emerald-950/20 dark:border-green-900">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className="p-2 bg-green-100 dark:bg-green-900 rounded-full">
                    <span className="font-bold text-green-700 dark:text-green-300">₹</span>
                  </div>
                  INR Wallet
                </CardTitle>
                <CardDescription>Indian Rupee Balance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Available to Withdraw</p>
                  <div className="text-4xl font-bold">₹{user.walletINR.available.toLocaleString()}</div>
                </div>
                <div className="mt-4 pt-4 border-t border-green-200 dark:border-green-900 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium">Pending: ₹{user.walletINR.pending.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Unlocks in 14 days</p>
                  </div>
                  <Button variant="outline" className="border-green-600 text-green-700 hover:bg-green-100">Withdraw</Button>
                </div>
              </CardContent>
            </Card>

            {/* USD Wallet */}
            <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200 dark:from-blue-950/20 dark:to-indigo-950/20 dark:border-blue-900">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-full">
                    <span className="font-bold text-blue-700 dark:text-blue-300">$</span>
                  </div>
                  USD Wallet
                </CardTitle>
                <CardDescription>US Dollar Balance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Available to Withdraw</p>
                  <div className="text-4xl font-bold">${user.walletUSD.available.toLocaleString()}</div>
                </div>
                <div className="mt-4 pt-4 border-t border-blue-200 dark:border-blue-900 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium">Pending: ${user.walletUSD.pending.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Unlocks in 14 days</p>
                  </div>
                  <Button variant="outline" className="border-blue-600 text-blue-700 hover:bg-blue-100">Withdraw</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="referrals">
          <Card>
            <CardHeader>
              <CardTitle>Referral Program</CardTitle>
              <CardDescription>Share your unique code to earn rewards.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col md:flex-row items-center justify-between gap-6 p-6 bg-muted rounded-lg">
                <div className="space-y-2">
                  <h3 className="font-semibold text-lg">Your Referral Code</h3>
                  <div className="flex items-center gap-2">
                    <code className="text-3xl font-mono font-bold tracking-wider">{user.referralCode}</code>
                    <Button size="icon" variant="ghost">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button className="gap-2">
                    <Share2 className="h-4 w-4" /> Share Link
                  </Button>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-4">How it works</h3>
                <div className="grid gap-4 md:grid-cols-3 text-sm">
                  <div className="p-4 border rounded-lg">
                    <div className="font-bold mb-1">1. Share Code</div>
                    <p className="text-muted-foreground">Send your unique code to friends and colleagues.</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="font-bold mb-1">2. They Register</div>
                    <p className="text-muted-foreground">They sign up using your code.</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="font-bold mb-1">3. You Earn</div>
                    <p className="text-muted-foreground">Get 10% of their registration fee instantly.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Transaction History</CardTitle>
                <CardDescription>Recent earnings and payouts.</CardDescription>
              </div>
              <Button variant="outline" size="sm" className="gap-2">
                <Download className="h-4 w-4" /> Export CSV
              </Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Transaction ID</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead className="text-right">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.map((tx) => (
                    <TableRow key={tx.id}>
                      <TableCell>{tx.date}</TableCell>
                      <TableCell className="font-mono text-xs">{tx.id}</TableCell>
                      <TableCell>{tx.type}</TableCell>
                      <TableCell className={`text-right font-medium ${tx.amount > 0 ? 'text-green-600' : 'text-foreground'}`}>
                        {tx.amount > 0 ? '+' : ''}{tx.amount} {tx.currency}
                      </TableCell>
                      <TableCell className="text-right">
                        <Badge variant={tx.status === 'completed' ? 'default' : 'secondary'} className="capitalize">
                          {tx.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
