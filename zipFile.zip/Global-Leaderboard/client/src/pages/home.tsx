import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  ArrowRight, 
  Trophy, 
  TrendingUp, 
  Users, 
  ShieldCheck,
  Check,
  Sparkles,
  Target,
  Zap,
  Globe,
  Award,
  BookOpen,
  Network,
  Star,
  Rocket,
  Crown
} from "lucide-react";

const topVCs = [
  { id: 1, name: "Y Combinator", totalFunds: "$2.5B", portfolioCompanies: 4500, avgInvestment: "$500K", successRate: "95%" },
  { id: 2, name: "500 Startups", totalFunds: "$1.8B", portfolioCompanies: 2800, avgInvestment: "$300K", successRate: "88%" },
  { id: 3, name: "Techstars", totalFunds: "$1.2B", portfolioCompanies: 3200, avgInvestment: "$400K", successRate: "92%" },
  { id: 4, name: "Sequoia Capital", totalFunds: "$85B", portfolioCompanies: 1200, avgInvestment: "$2M", successRate: "98%" },
  { id: 5, name: "Andreessen Horowitz", totalFunds: "$35B", portfolioCompanies: 800, avgInvestment: "$3M", successRate: "96%" },
];

const topUnicorns = [
  { rank: 1, company: "SpaceX", country: "United States", industry: "Industrials", valuation: 350 },
  { rank: 2, company: "ByteDance", country: "China", industry: "Media & Entertainment", valuation: 300 },
  { rank: 3, company: "OpenAI", country: "United States", industry: "Enterprise Tech", valuation: 300 },
  { rank: 4, company: "Stripe", country: "United States", industry: "Financial Services", valuation: 70 },
  { rank: 5, company: "SHEIN", country: "Singapore", industry: "Consumer & Retail", valuation: 66 },
];

const valueServices = [
  { name: "Professional Assessment", cost: "$15,000 to $30,000", icon: <Target className="h-6 w-6" /> },
  { name: "Multi-Method Valuation", cost: "$50,000 to $90,000", icon: <TrendingUp className="h-6 w-6" /> },
  { name: "Global Network Access", cost: "$30,000 to $60,000", icon: <Network className="h-6 w-6" /> },
  { name: "Recognition & Credibility", cost: "$20,000 to $30,000", icon: <Award className="h-6 w-6" /> },
  { name: "Educational Resources", cost: "$5,000 to $15,000", icon: <BookOpen className="h-6 w-6" /> },
];

const earlyAccessRewards = [
  { tier: "Top 1%", plan: "Pro Max Ultra", worth: "₹1,00,000/Year", description: "Ultimate career domination package", color: "from-yellow-500 to-amber-600" },
  { tier: "Next 2%", plan: "Professional", worth: "₹60,000/Year", description: "Complete brand building solution", color: "from-purple-500 to-violet-600" },
  { tier: "Next 3%", plan: "Advanced", worth: "₹36,000/Year", description: "Expert-level skill development", color: "from-blue-500 to-cyan-600" },
  { tier: "Next 4%", plan: "Basic", worth: "₹24,000/Year", description: "Professional identity building", color: "from-green-500 to-emerald-600" },
  { tier: "Next 90%", plan: "Beginner", worth: "₹16,000/Year", description: "Career acceleration starter", color: "from-gray-500 to-slate-600" },
];

const pricingPlans = [
  {
    name: "Free Forever",
    price: "₹0",
    period: "Year",
    tagline: "Start your journey with zero cost",
    features: [
      "Basic AI expertise resources",
      "Basic Template website",
      "1 Email ID",
      "50 MB Data Storage",
      "Basic Firewall",
      "Online Resources Support"
    ],
    badge: "FREE FOREVER",
    popular: false
  },
  {
    name: "Beginner",
    price: "₹16,000",
    period: "Year",
    tagline: "Ignite Your Idea!",
    features: [
      "Basic Virtual Space",
      "1 Participation Credit",
      "1 Basic AI Assistant",
      "Basic Template Website",
      "1 Email ID",
      "100 MB Data Storage",
      "Online Resources Support"
    ],
    badge: "FREE FOR 1 MONTH",
    popular: false
  },
  {
    name: "Basic",
    price: "₹24,000",
    period: "Year",
    tagline: "Nurture Your Vision!",
    features: [
      "Customizable Virtual Office",
      "5 Participation Credits",
      "1 Advanced AI Assistant",
      "Customizable Template Website",
      "5 Email IDs",
      "1 GB Data Storage",
      "Access to Online Community",
      "AI-powered Chatbot"
    ],
    badge: "FREE FOR 3 MONTHS",
    popular: true
  },
  {
    name: "Advanced",
    price: "₹36,000",
    period: "Year",
    tagline: "Accelerate Your Growth!",
    features: [
      "Advanced Virtual Office with AI",
      "10 Participation Credits",
      "2 Advanced AI Assistants",
      "Custom Design with E-commerce",
      "10 Email IDs",
      "5 GB Data Storage",
      "AI-powered Content Generation",
      "Exclusive Online Events"
    ],
    badge: "FREE FOR 6 MONTHS",
    popular: false
  },
  {
    name: "Professional",
    price: "₹60,000",
    period: "Year",
    tagline: "Connect with Unicorns!",
    features: [
      "Premium Virtual Office with VR",
      "20 Participation Credits",
      "3 High-end AI Assistants",
      "AI-powered Content Generation",
      "20 Email IDs",
      "10 GB Data Storage",
      "Dedicated Unicorn Coach",
      "VIP Events Access"
    ],
    badge: "FREE FOR 9 MONTHS",
    popular: false
  },
  {
    name: "Pro Max Ultra",
    price: "₹1,00,000",
    period: "Year",
    tagline: "Create Your Legacy!",
    features: [
      "Ultra-Premium Virtual Office",
      "50 Participation Credits",
      "5 Top-notch AI Assistants",
      "VR + AI Content Generation",
      "50 Email IDs",
      "50 GB Data Storage",
      "Unicorn Mentorship",
      "24/7 Dedicated AI Support"
    ],
    badge: "FREE FOR 1 YEAR",
    popular: false
  }
];

export default function Home() {
  return (
    <div className="flex flex-col items-center space-y-16 py-8">
      {/* Hero Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center space-y-6 max-w-4xl px-4"
      >
        <Badge className="bg-primary/10 text-primary hover:bg-primary/20 text-sm py-1 px-4">
          Transform Your Startup's Future @ HyperSpeed
        </Badge>
        
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
          <span className="text-muted-foreground">90% of startups fail,</span>
          <br />
          <span className="text-primary">but most failures are preventable.</span>
        </h1>
        
        <div className="flex flex-col items-center gap-2">
          <p className="text-2xl md:text-3xl font-bold">
            Upto <span className="text-primary">$225,000</span> worth of benefits
          </p>
          <p className="text-xl md:text-2xl">
            for just <span className="text-primary font-bold">₹999/year</span> <span className="text-muted-foreground">($14.99/year)</span>
          </p>
          <p className="text-xs text-muted-foreground">Annual Listing Fee • Premium benefits included FREE as promotion</p>
          <div className="mt-4 p-4 bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-lg shadow-lg animate-pulse">
            <p className="text-sm font-bold">Price doubles after 100 registrations!</p>
            <p className="text-lg font-bold">₹999/year → ₹1,999/year ($14.99 → $29.99)</p>
            <p className="text-xs mt-1 opacity-90">Lock in the lowest price now!</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
          <Link href="/register">
            <Button size="lg" className="h-14 px-10 text-lg font-semibold" data-testid="button-get-started">
              Get Started Now <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
          <Link href="/leaderboard">
            <Button variant="outline" size="lg" className="h-14 px-10 text-lg" data-testid="button-view-leaderboard">
              View Leaderboard
            </Button>
          </Link>
        </div>
      </motion.section>

      {/* Stats Bar */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="w-full max-w-5xl"
      >
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 bg-primary/5 rounded-2xl border border-primary/20">
          <StatCard value="Upto $225K" label="Worth of benefits" />
          <StatCard value="98" label="Point multi-layered evaluation" />
          <StatCard value="35%+" label="Improvement in assessments" />
          <StatCard value="60%+" label="Higher funding success" />
        </div>
      </motion.section>

      {/* Top VCs Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="w-full max-w-6xl px-4"
      >
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2">Top VCs of 2025</h2>
          <p className="text-muted-foreground">Discover top venture capital firms across different funding stages</p>
        </div>
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="w-16">ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead className="text-right">Total Funds</TableHead>
                  <TableHead className="text-right">Portfolio Companies</TableHead>
                  <TableHead className="text-right">Avg Investment</TableHead>
                  <TableHead className="text-right">Success Rate</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topVCs.map((vc) => (
                  <TableRow key={vc.id} data-testid={`vc-row-${vc.id}`}>
                    <TableCell className="font-medium">{vc.id}</TableCell>
                    <TableCell className="font-semibold">{vc.name}</TableCell>
                    <TableCell className="text-right">{vc.totalFunds}</TableCell>
                    <TableCell className="text-right">{vc.portfolioCompanies}</TableCell>
                    <TableCell className="text-right">{vc.avgInvestment}</TableCell>
                    <TableCell className="text-right text-green-600 font-semibold">{vc.successRate}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        <div className="text-center mt-4">
          <Link href="/leaderboard">
            <Button variant="link" className="text-primary">
              VC List <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </motion.section>

      {/* Top Unicorns Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="w-full max-w-6xl px-4"
      >
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2">Top Unicorns of 2025</h2>
          <p className="text-muted-foreground">Discover the world's most valuable startups</p>
        </div>
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="w-16">Rank</TableHead>
                  <TableHead>Company</TableHead>
                  <TableHead>Country</TableHead>
                  <TableHead>Industry</TableHead>
                  <TableHead className="text-right">Valuation ($B)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topUnicorns.map((unicorn) => (
                  <TableRow key={unicorn.rank} data-testid={`unicorn-row-${unicorn.rank}`}>
                    <TableCell>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                        unicorn.rank === 1 ? "bg-yellow-500/20 text-yellow-600" :
                        unicorn.rank === 2 ? "bg-gray-300/30 text-gray-600" :
                        unicorn.rank === 3 ? "bg-amber-600/20 text-amber-700" :
                        "bg-muted text-muted-foreground"
                      }`}>
                        {unicorn.rank}
                      </div>
                    </TableCell>
                    <TableCell className="font-semibold">{unicorn.company}</TableCell>
                    <TableCell>{unicorn.country}</TableCell>
                    <TableCell>{unicorn.industry}</TableCell>
                    <TableCell className="text-right font-bold text-primary">${unicorn.valuation}B</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        <div className="text-center mt-4">
          <Link href="/leaderboard">
            <Button variant="link" className="text-primary">
              See Leaderboard <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </motion.section>

      {/* Why Trust Us */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.35 }}
        className="w-full max-w-4xl px-4 text-center"
      >
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="py-12">
            <h2 className="text-3xl font-bold mb-6">Why Trust Us?</h2>
            <div className="space-y-2 text-xl text-muted-foreground">
              <p>We know what startups <span className="text-primary font-semibold">need</span>.</p>
              <p>We know what startups <span className="text-primary font-semibold">want</span>.</p>
              <p>We know which startups can <span className="text-primary font-semibold">win</span>.</p>
            </div>
            <Link href="/register">
              <Button size="lg" className="mt-8 h-12 px-8" data-testid="button-register-trust">
                Register Now <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      </motion.section>

      {/* Value Justification */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="w-full max-w-6xl px-4"
      >
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2">Comprehensive Value Justification</h2>
          <p className="text-muted-foreground">We've bundled five premium services, normally totaling $120,000 to $225,000, all for just ₹999</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {valueServices.map((service, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg text-primary">
                    {service.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">{service.name}</h3>
                    <p className="text-sm text-muted-foreground line-through">{service.cost}</p>
                    <Badge variant="secondary" className="mt-2 bg-green-100 text-green-700">
                      <Check className="h-3 w-3 mr-1" /> Included
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          <Card className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
            <CardContent className="p-6 flex flex-col justify-center h-full">
              <div className="text-center">
                <p className="text-sm opacity-80">TOTAL VALUE</p>
                <p className="text-2xl font-bold line-through opacity-70">$120,000 to $225,000</p>
                <p className="text-4xl font-bold mt-2">₹999</p>
                <p className="text-sm mt-2">Unbeatable Offer!</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.section>

      {/* How It Works */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.45 }}
        className="w-full max-w-5xl px-4"
      >
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2">How It Works</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Target className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-2">Assess</h3>
            <p className="text-muted-foreground">98-point evaluation</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <TrendingUp className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-2">Valuate</h3>
            <p className="text-muted-foreground">5 professional methods</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Users className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-2">Connect</h3>
            <p className="text-muted-foreground">Intelligent matching engine</p>
          </div>
        </div>
      </motion.section>

      {/* Early Access Rewards */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="w-full max-w-6xl px-4"
      >
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2 flex items-center justify-center gap-2">
            <Sparkles className="h-8 w-8 text-yellow-500" />
            Exclusive Early Access Rewards
          </h2>
          <p className="text-muted-foreground">The first 10% of registrants get their annual subscription FREE!</p>
        </div>
        <div className="space-y-4">
          {earlyAccessRewards.map((reward, index) => (
            <Card key={index} className={`overflow-hidden ${index === 0 ? 'ring-2 ring-yellow-500' : ''}`}>
              <div className={`h-2 bg-gradient-to-r ${reward.color}`} />
              <CardContent className="p-4 flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <Badge className={`bg-gradient-to-r ${reward.color} text-white px-4 py-1`}>
                    {reward.tier}
                  </Badge>
                  <div>
                    <p className="font-bold">{reward.plan} Plan</p>
                    <p className="text-sm text-muted-foreground">{reward.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-primary">{reward.worth}</p>
                  <Badge variant="secondary" className="bg-green-100 text-green-700">FREE for 1 Year</Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="text-center mt-6 p-4 bg-green-50 dark:bg-green-950/20 rounded-lg">
          <p className="text-green-700 dark:text-green-400 font-medium">
            <Check className="inline h-4 w-4 mr-1" />
            Even if you miss the top tier, you still get at least ₹16,000 worth of value!
          </p>
        </div>
        <div className="text-center mt-4 p-4 bg-primary/5 rounded-lg">
          <p className="text-sm">
            <Rocket className="inline h-4 w-4 mr-1 text-primary" />
            <strong>Beat the system:</strong> Pay a little extra to become the highest-paying registrant of the day and jump the queue for top-tier rewards!
          </p>
        </div>
      </motion.section>

      {/* Pricing Plans */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.55 }}
        className="w-full max-w-7xl px-4"
      >
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2 flex items-center justify-center gap-2">
            <Star className="h-8 w-8 text-yellow-500" />
            Subscription Plans for Startups
          </h2>
          <p className="text-muted-foreground">Choose from our comprehensive range of plans designed to accelerate your startup growth</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pricingPlans.map((plan, index) => (
            <Card key={index} className={`relative ${plan.popular ? 'ring-2 ring-primary' : ''}`}>
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary">
                  Most Popular
                </Badge>
              )}
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-xl">{plan.name}</CardTitle>
                <div className="mt-2">
                  <span className="text-3xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground">/{plan.period}</span>
                </div>
                <p className="text-sm text-muted-foreground mt-1">{plan.tagline}</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-2">
                  {plan.features.map((feature, fIndex) => (
                    <li key={fIndex} className="flex items-start gap-2 text-sm">
                      <Check className="h-4 w-4 text-green-500 shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Badge className="w-full justify-center py-1 bg-primary/10 text-primary hover:bg-primary/20">
                  {plan.badge}
                </Badge>
                <Link href="/register" className="block">
                  <Button className="w-full" variant={plan.popular ? "default" : "outline"} data-testid={`button-choose-${plan.name.toLowerCase().replace(/\s+/g, '-')}`}>
                    Choose {plan.name}
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </motion.section>

      {/* Final CTA */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.6 }}
        className="w-full max-w-4xl px-4"
      >
        <Card className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground overflow-hidden">
          <CardContent className="py-12 text-center">
            <Rocket className="h-12 w-12 mx-auto mb-4" />
            <h2 className="text-3xl font-bold mb-4">Join i2u.ai, ₹999/year ($14.99/year) Today!</h2>
            <p className="text-lg opacity-90 mb-4 max-w-2xl mx-auto">
              Your annual listing fee gives you access to our premium resources, AI-powered tools, and global startup network. All benefits included FREE as promotion!
            </p>
            <div className="bg-white/10 rounded-lg p-4 mb-6 max-w-lg mx-auto">
              <p className="text-sm font-medium mb-3">Annual Listing Fee Tiers:</p>
              <div className="space-y-2 text-sm">
                <div className="bg-green-500/30 rounded-lg p-3 border-2 border-green-400">
                  <p className="font-bold text-lg">First 100: ₹999/year ($14.99/year)</p>
                  <p className="text-green-300 text-xs">← YOU ARE HERE - Best Price!</p>
                </div>
                <div className="bg-orange-500/20 rounded-lg p-2 border border-orange-400/50">
                  <p className="font-bold">101-500: ₹1,999/year ($29.99/year)</p>
                  <p className="text-orange-300 text-xs">2x price increase!</p>
                </div>
                <div className="bg-red-500/20 rounded-lg p-2 border border-red-400/50">
                  <p className="font-bold">501+: ₹2,999/year ($39.99/year) + $99 Assessment</p>
                  <p className="text-red-300 text-xs">3x price increase!</p>
                </div>
              </div>
              <p className="text-xs mt-3 opacity-80">Referral bonus: Earn on all spending by your referrals while you're subscribed!</p>
            </div>
            <Link href="/register">
              <Button size="lg" variant="secondary" className="h-14 px-10 text-lg font-semibold" data-testid="button-pay-now">
                Pay Now ₹999/year ($14.99/year) <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      </motion.section>
    </div>
  );
}

function StatCard({ value, label }: { value: string; label: string }) {
  return (
    <div className="text-center p-4">
      <div className="text-2xl md:text-3xl font-bold text-primary">{value}</div>
      <div className="text-sm text-muted-foreground mt-1">{label}</div>
    </div>
  );
}
