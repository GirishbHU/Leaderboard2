import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { COUNTRIES, SECTORS, registerUser } from "@/lib/mockData";
import { useLocation } from "wouter";
import { Check, Loader2, CreditCard, Shield, Star, Globe, Trophy, FlaskConical } from "lucide-react";
import { CashfreeButton } from "@/components/CashfreeButton";
import PayPalButton from "@/components/PayPalButton";
import { useQuery } from "@tanstack/react-query";

// Schemas
const step1Schema = z.object({
  role: z.enum(["builder", "investor", "enabler", "startup", "professional", "vc", "ngo", "government", "influencer", "accelerator", "mentor", "service_provider", "angel"], {
    required_error: "Please select a role",
  }),
});

const step2Schema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  country: z.string().min(1, "Please select a country"),
  sector: z.string().min(1, "Please select a sector"),
  displayPreference: z.enum(["real_name", "username", "anonymous", "fancy_username"]),
  currency: z.enum(["INR", "USD"]),
});

// Pricing configuration by role
const PRICING = {
  // Professionals/Enablers get lower pricing
  professional: { INR: 99, USD: 1.49, futureINR: 999, futureUSD: 14.99 },
  enabler: { INR: 99, USD: 1.49, futureINR: 999, futureUSD: 14.99 },
  mentor: { INR: 99, USD: 1.49, futureINR: 999, futureUSD: 14.99 },
  service_provider: { INR: 99, USD: 1.49, futureINR: 999, futureUSD: 14.99 },
  // Default pricing for startups, investors, etc.
  default: { INR: 999, USD: 14.99, futureINR: 1999, futureUSD: 29.99 },
};

function getPricing(role: string) {
  return PRICING[role as keyof typeof PRICING] || PRICING.default;
}

export default function Register() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<any>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPreviewOption, setShowPreviewOption] = useState(false);
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  const { data: previewStatus } = useQuery({
    queryKey: ["/api/preview/status"],
    queryFn: async () => {
      const response = await fetch("/api/preview/status");
      return response.json();
    },
  });
  
  const isMockMode = previewStatus?.isMockMode || false;
  
  // Get pricing based on selected role
  const pricing = getPricing(formData.role || "default");

  const form1 = useForm<z.infer<typeof step1Schema>>({
    resolver: zodResolver(step1Schema),
    defaultValues: { role: "startup" }
  });

  const form2 = useForm<z.infer<typeof step2Schema>>({
    resolver: zodResolver(step2Schema),
    defaultValues: {
      name: "",
      email: "",
      country: "",
      sector: "",
      displayPreference: "real_name",
      currency: "USD"
    }
  });

  const onStep1Submit = (data: z.infer<typeof step1Schema>) => {
    setFormData({ ...formData, ...data });
    setStep(2);
  };

  const onStep2Submit = (data: z.infer<typeof step2Schema>) => {
    setFormData({ ...formData, ...data });
    setStep(3);
  };

  const handlePaymentSuccess = async (paymentData: any) => {
    setIsSubmitting(true);
    
    // Handle both Cashfree and PayPal response shapes
    // Cashfree: { orderId, ...details }
    // PayPal capture response: { id, status, purchase_units: [...] } (raw PayPal API response)
    // PayPal capture ID may be in purchase_units[0].payments.captures[0].id
    let paymentId = paymentData.orderId || paymentData.id;
    
    // Check PayPal nested capture ID if top-level id not found
    if (!paymentId && paymentData.purchase_units?.[0]?.payments?.captures?.[0]?.id) {
      paymentId = paymentData.purchase_units[0].payments.captures[0].id;
    }
    
    // Final fallback with timestamp for uniqueness
    if (!paymentId) {
      paymentId = `payment_${Date.now()}`;
    }
    
    const paymentStatus = paymentData.status || "COMPLETED";
    
    const finalData = { 
      ...formData, 
      paymentId,
      paymentStatus,
      paymentProvider: formData.currency === "INR" ? "cashfree" : "paypal"
    };
    
    console.log("Payment success data:", paymentData);
    console.log("Registering with:", finalData);
    
    try {
      await registerUser(finalData);
      toast({
        title: "Registration Successful!",
        description: "Welcome to the leaderboard. Redirecting to dashboard...",
      });
      setTimeout(() => {
        setLocation("/dashboard");
      }, 2000);
    } catch (error) {
      toast({
        title: "Registration Failed",
        description: "Payment received but registration failed. Please contact support.",
        variant: "destructive"
      });
      setIsSubmitting(false);
    }
  };

  const handlePaymentFailure = (error: string) => {
    toast({
      title: "Payment Failed",
      description: error || "Something went wrong. Please try again.",
      variant: "destructive"
    });
  };

  const handlePreviewPayment = async () => {
    setIsSubmitting(true);
    
    try {
      const response = await fetch("/api/register/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          role: formData.role,
          country: formData.country,
          sector: formData.sector,
          currency: formData.currency || "USD",
          displayPreference: formData.displayPreference || "real_name",
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || "Registration failed");
      }
      
      toast({
        title: "Preview Registration Complete!",
        description: "You're now in Preview Mode. Explore all features with simulated data.",
      });
      setTimeout(() => {
        setLocation("/dashboard");
      }, 2000);
    } catch (error: any) {
      toast({
        title: "Registration Failed",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive"
      });
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-12 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-center mb-4">Join the Revolution</h1>
        <div className="flex justify-center items-center gap-4">
          <StepIndicator current={step} number={1} label="Role" />
          <div className="w-12 h-0.5 bg-muted" />
          <StepIndicator current={step} number={2} label="Profile" />
          <div className="w-12 h-0.5 bg-muted" />
          <StepIndicator current={step} number={3} label="Payment" />
        </div>
      </div>

      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div
            key="step1"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Choose Your Role</CardTitle>
                <CardDescription>How do you participate in the startup ecosystem?</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form1}>
                  <form onSubmit={form1.handleSubmit(onStep1Submit)} className="space-y-6">
                    <FormField
                      control={form1.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="grid grid-cols-1 md:grid-cols-3 gap-4"
                            >
                              <RoleCard value="startup" title="Builder / Startup" description="I am building a product or company." />
                              <RoleCard value="investor" title="Investor / VC" description="I fund and support startups." />
                              <RoleCard value="enabler" title="Enabler / Pro" description="I provide services or mentorship." />
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="flex justify-end">
                      <Button type="submit" size="lg">Next Step</Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div
            key="step2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Your Profile</CardTitle>
                <CardDescription>Tell us a bit about yourself to get verified.</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form2}>
                  <form onSubmit={form2.handleSubmit(onStep2Submit)} className="space-y-4">
                    <FormField
                      control={form2.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form2.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input placeholder="john@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form2.control}
                        name="country"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Country</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select Country" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {COUNTRIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form2.control}
                        name="sector"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Sector</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select Sector" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {SECTORS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form2.control}
                      name="currency"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>Preferred Currency</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex space-x-4"
                            >
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="USD" />
                                </FormControl>
                                <FormLabel className="font-normal">USD ($)</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="INR" />
                                </FormControl>
                                <FormLabel className="font-normal">INR (₹)</FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex justify-between pt-4">
                      <Button type="button" variant="outline" onClick={() => setStep(1)}>Back</Button>
                      <Button type="submit">Next Step</Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div
            key="step3"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Complete Registration</CardTitle>
                <CardDescription>Secure your spot on the global leaderboard.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-primary/5 p-6 rounded-lg mb-6 border border-primary/20 text-center">
                  <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-2">Annual Listing Fee</p>
                  <div className="text-4xl font-bold text-primary mb-1">
                    {formData.currency === "INR" ? `₹${pricing.INR}/year` : `$${pricing.USD}/year`}
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">Premium benefits included FREE as promotion</p>
                  <p className="text-xs bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-200 px-3 py-1 rounded-full inline-block">
                    {formData.currency === "INR" 
                      ? "Price increases by ₹100/year after every 100 registrations until ₹999/year"
                      : "Price increases by $1.50/year after every 100 registrations until $14.99/year"}
                  </p>
                </div>

                <div className="mb-6">
                  <h3 className="font-semibold mb-4 text-center">What You Get</h3>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex items-center gap-2">
                      <Globe className="h-4 w-4 text-primary" />
                      <span>Global Leaderboard</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Trophy className="h-4 w-4 text-primary" />
                      <span>Verified Badge</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-primary" />
                      <span>Premium Profile</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Priority Support</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  {showPreviewOption ? (
                    <div className="space-y-4">
                      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
                        <div className="flex items-start gap-3">
                          <FlaskConical className="h-5 w-5 text-amber-600 dark:text-amber-400 mt-0.5" />
                          <div>
                            <h4 className="font-semibold text-amber-800 dark:text-amber-200">Preview Mode</h4>
                            <p className="text-sm text-amber-700 dark:text-amber-300 mt-1">
                              This is a demonstration environment. No real payment will be processed. 
                              You'll get access to explore all features with simulated data.
                            </p>
                          </div>
                        </div>
                      </div>
                      
                      {isSubmitting ? (
                        <div className="flex items-center justify-center py-4">
                          <Loader2 className="h-6 w-6 animate-spin mr-2" />
                          <span>Setting up your preview account...</span>
                        </div>
                      ) : (
                        <Button
                          onClick={handlePreviewPayment}
                          className="w-full h-12 text-lg"
                          data-testid="button-preview-payment"
                        >
                          <FlaskConical className="mr-2 h-5 w-5" />
                          Start Preview Mode (No Payment)
                        </Button>
                      )}
                      
                      <Button
                        type="button"
                        variant="ghost"
                        onClick={() => setShowPreviewOption(false)}
                        className="w-full text-sm"
                        data-testid="button-show-real-payment"
                      >
                        Use real payment instead
                      </Button>
                    </div>
                  ) : (
                    <>
                      <p className="text-sm text-center text-muted-foreground">
                        {formData.currency === "INR" 
                          ? "Pay securely with Cashfree (UPI, Cards, Net Banking)" 
                          : "Pay securely with PayPal"}
                      </p>
                      
                      {isSubmitting ? (
                        <div className="flex items-center justify-center py-4">
                          <Loader2 className="h-6 w-6 animate-spin mr-2" />
                          <span>Completing registration...</span>
                        </div>
                      ) : formData.currency === "INR" ? (
                        <CashfreeButton
                          amount={pricing.INR}
                          customerId={`user_${Date.now()}`}
                          customerName={formData.name || "User"}
                          customerEmail={formData.email || "user@example.com"}
                          customerPhone="9999999999"
                          onSuccess={(orderId, details) => handlePaymentSuccess({ orderId, ...details })}
                          onFailure={handlePaymentFailure}
                          className="w-full h-12 text-lg"
                        />
                      ) : (
                        <div className="flex justify-center" data-testid="paypal-button-container">
                          <PayPalButton
                            amount={pricing.USD.toString()}
                            currency="USD"
                            intent="CAPTURE"
                            onSuccess={handlePaymentSuccess}
                          />
                        </div>
                      )}
                      
                      <div className="pt-4 border-t">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setShowPreviewOption(true)}
                          className="w-full text-sm"
                          data-testid="button-try-preview"
                        >
                          <FlaskConical className="mr-2 h-4 w-4" />
                          Try Preview Mode (No Payment Required)
                        </Button>
                        <p className="text-xs text-center text-muted-foreground mt-2">
                          Explore all features with simulated data before committing
                        </p>
                      </div>
                    </>
                  )}
                </div>

                <div className="flex justify-start pt-6 border-t mt-6">
                  <Button type="button" variant="outline" onClick={() => setStep(2)}>
                    Back
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StepIndicator({ current, number, label }: { current: number, number: number, label: string }) {
  const isActive = current === number;
  const isCompleted = current > number;

  return (
    <div className="flex flex-col items-center gap-2">
      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-colors ${
        isActive ? "bg-primary text-primary-foreground" : 
        isCompleted ? "bg-green-500 text-white" : "bg-muted text-muted-foreground"
      }`}>
        {isCompleted ? <Check className="w-5 h-5" /> : number}
      </div>
      <span className={`text-xs font-medium ${isActive ? "text-primary" : "text-muted-foreground"}`}>
        {label}
      </span>
    </div>
  );
}

function RoleCard({ value, title, description }: { value: string, title: string, description: string }) {
  return (
    <FormItem className="space-y-0">
      <FormLabel className="[&:has([data-state=checked])>div]:border-primary [&:has([data-state=checked])>div]:bg-primary/5">
        <FormControl>
          <RadioGroupItem value={value} className="sr-only" />
        </FormControl>
        <div className="border-2 rounded-lg p-6 cursor-pointer hover:bg-muted/50 transition-all h-full">
          <h3 className="font-bold text-lg mb-2">{title}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </FormLabel>
    </FormItem>
  );
}
