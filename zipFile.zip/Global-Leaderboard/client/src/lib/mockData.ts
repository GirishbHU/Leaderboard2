import { z } from "zod";

// --- Types ---

export type UserRole = "builder" | "investor" | "enabler" | "startup" | "influencer" | "professional" | "accelerator" | "ngo" | "vc" | "government" | "mentor" | "service_provider" | "angel";
export type Currency = "INR" | "USD";
export type DisplayPreference = "real_name" | "username" | "anonymous" | "fancy_username";
export type SubscriptionTier = "Beginner" | "Professional" | "Advanced" | "Pro Max Ultra";

export interface User {
  id: string;
  email: string;
  name: string; // real name
  username?: string; // generated or chosen
  role: UserRole;
  country: string;
  sector: string;
  currency: Currency;
  displayPreference: DisplayPreference;
  companyName?: string;
  startupStage?: string;
  
  registrationNumber: number;
  registrationDate: string;
  
  referralCode: string;
  referralCount: number;
  referralEarningsINR: number;
  referralEarningsUSD: number;
  showEarningsPublicly: boolean; // New Flag
  
  walletINR: {
    available: number;
    pending: number;
  };
  walletUSD: {
    available: number;
    pending: number;
  };
  
  leaderboardRank: number;
  percentile: number;
  subscriptionTier: SubscriptionTier;
  status: "verified" | "pending";
}

// --- Mock Data ---

// Helper to generate a random user if needed, but we will mostly rely on the parsed list
// We will use a subset of the CSV data provided in the prompt

export const MOCK_USERS: User[] = [
  {
    registrationNumber: 1,
    id: "278f0f3e-411f-4c00-99e6-1bab1dfd487d",
    email: "user1@example.com",
    name: "User One", // Placeholder as CSV didn't have name column explicitly in snippet but implies it
    username: "Digital Dreams",
    role: "startup",
    country: "Vietnam",
    sector: "Parking & Mobility",
    displayPreference: "real_name",
    currency: "INR",
    companyName: "Digital Dreams",
    startupStage: "Idea",
    referralCode: "REF81482",
    referralCount: 27,
    referralEarningsINR: 25000,
    referralEarningsUSD: 120,
    showEarningsPublicly: true,
    walletINR: { available: 0, pending: 0 },
    walletUSD: { available: 0, pending: 0 },
    leaderboardRank: 1,
    percentile: 0.29,
    subscriptionTier: "Pro Max Ultra",
    registrationDate: "2025-12-07T05:27:29.790743Z",
    status: "verified"
  },
  {
    registrationNumber: 2,
    id: "25039bca-0a28-4ff8-a3db-c006d9d36995",
    email: "morgan_2@startup.io",
    name: "Morgan Two",
    role: "influencer",
    country: "Armenia",
    sector: "Tax Planning",
    displayPreference: "real_name",
    currency: "USD",
    referralCode: "REF10851",
    referralCount: 0,
    referralEarningsINR: 199.80,
    referralEarningsUSD: 3.00,
    showEarningsPublicly: true,
    walletINR: { available: 99.90, pending: 99.90 },
    walletUSD: { available: 1.50, pending: 1.50 },
    leaderboardRank: 2,
    percentile: 0.57,
    subscriptionTier: "Pro Max Ultra",
    registrationDate: "2025-11-06T18:27:29.791892Z",
    status: "verified"
  },
  {
    registrationNumber: 3,
    id: "fdf1ae9a-b9b3-4039-be57-c641b44d9726",
    email: "user3@example.com",
    name: "User Three",
    role: "accelerator",
    country: "Hungary",
    sector: "Smart Home & IoT Devices",
    displayPreference: "real_name",
    currency: "USD",
    referralCode: "REF57052",
    referralCount: 38,
    referralEarningsINR: 199.80,
    referralEarningsUSD: 3.00,
    showEarningsPublicly: true,
    walletINR: { available: 99.90, pending: 99.90 },
    walletUSD: { available: 1.50, pending: 1.50 },
    leaderboardRank: 3,
    percentile: 0.86,
    subscriptionTier: "Pro Max Ultra",
    registrationDate: "2025-11-19T23:27:29.792030Z",
    status: "pending"
  },
  {
    registrationNumber: 4,
    id: "579b1fa6-0c3a-4c47-a3a7-969da9c9b060",
    email: "user4@example.com",
    name: "User Four",
    role: "ngo",
    country: "Qatar",
    sector: "Enterprise Software",
    displayPreference: "fancy_username",
    currency: "INR",
    referralCode: "REF91070",
    referralCount: 0,
    referralEarningsINR: 199.80,
    referralEarningsUSD: 3.00,
    showEarningsPublicly: false,
    walletINR: { available: 99.90, pending: 99.90 },
    walletUSD: { available: 1.50, pending: 1.50 },
    leaderboardRank: 4,
    percentile: 1.14,
    subscriptionTier: "Advanced",
    registrationDate: "2025-10-21T06:27:29.792111Z",
    status: "pending"
  },
  {
    registrationNumber: 5,
    id: "8c06162d-ae58-4950-8894-ce6717360ad4",
    email: "user5@example.com",
    name: "User Five",
    role: "professional",
    country: "Bahrain",
    sector: "Language Learning",
    displayPreference: "fancy_username",
    currency: "INR",
    companyName: "VirtualWorld Tech",
    referralCode: "REF46434",
    referralCount: 0,
    referralEarningsINR: 0,
    referralEarningsUSD: 0,
    showEarningsPublicly: true,
    walletINR: { available: 0, pending: 0 },
    walletUSD: { available: 0, pending: 0 },
    leaderboardRank: 5,
    percentile: 1.43,
    subscriptionTier: "Advanced",
    registrationDate: "2025-12-07T14:27:29.792239Z",
    status: "verified"
  },
  // Adding more from the CSV manually for variety
  {
    registrationNumber: 10,
    id: "524a352b-808f-4b75-91e8-43abf22f6bac",
    email: "user10@example.com",
    name: "User Ten",
    role: "government",
    country: "Singapore",
    sector: "Logistics & Supply Chain",
    displayPreference: "fancy_username",
    currency: "USD",
    referralCode: "REF42953",
    referralCount: 0,
    referralEarningsINR: 199.80,
    referralEarningsUSD: 3.00,
    showEarningsPublicly: true,
    walletINR: { available: 99.90, pending: 99.90 },
    walletUSD: { available: 1.50, pending: 1.50 },
    leaderboardRank: 10,
    percentile: 2.86,
    subscriptionTier: "Advanced",
    registrationDate: "2025-11-14T10:27:29.792835Z",
    status: "verified"
  },
  {
    registrationNumber: 35,
    id: "2459b91e-1a88-4428-b12d-31f0217de397",
    email: "user35@example.com",
    name: "User ThirtyFive",
    role: "startup",
    country: "Canada",
    sector: "Government Tech",
    displayPreference: "real_name",
    currency: "USD",
    companyName: "RiskGuard Systems",
    startupStage: "Pre-seed",
    referralCode: "REF55309",
    referralCount: 20,
    referralEarningsINR: 199.80,
    referralEarningsUSD: 3.00,
    showEarningsPublicly: true,
    walletINR: { available: 99.90, pending: 99.90 },
    walletUSD: { available: 1.50, pending: 1.50 },
    leaderboardRank: 35,
    percentile: 10.0,
    subscriptionTier: "Professional",
    registrationDate: "2025-11-05T13:27:29.795036Z",
    status: "pending"
  },
  {
    registrationNumber: 47,
    id: "ec0712fe-4906-4c68-846c-27fe50495de6",
    email: "user47@example.com",
    name: "User FortySeven",
    role: "startup",
    country: "Lebanon",
    sector: "Shipping & Freight",
    displayPreference: "fancy_username",
    currency: "USD",
    companyName: "TravelMate Global",
    startupStage: "Series B",
    referralCode: "REF89069",
    referralCount: 31,
    referralEarningsINR: 199.80,
    referralEarningsUSD: 3.00,
    showEarningsPublicly: false,
    walletINR: { available: 99.90, pending: 99.90 },
    walletUSD: { available: 1.50, pending: 1.50 },
    leaderboardRank: 47,
    percentile: 13.43,
    subscriptionTier: "Beginner",
    registrationDate: "2025-10-27T09:27:29.796004Z",
    status: "pending"
  }
];

// Generate more mock users to fill out the leaderboard up to 300
// Starting from rank 50 (assuming hardcoded ones are scattered below 50 mostly)
for (let i = 0; i < 260; i++) {
  const rank = 50 + i;
  MOCK_USERS.push({
    registrationNumber: rank,
    id: `mock-id-${rank}`,
    email: `user${rank}@example.com`,
    name: `User ${rank}`,
    role: ["startup", "investor", "enabler", "professional"][Math.floor(Math.random() * 4)] as UserRole,
    country: ["USA", "India", "UK", "Germany", "France", "Japan", "Brazil", "Canada", "Australia", "Singapore"][Math.floor(Math.random() * 10)],
    sector: ["Fintech", "Healthtech", "Edtech", "SaaS", "E-commerce", "AI", "Clean Energy"][Math.floor(Math.random() * 7)],
    displayPreference: "real_name",
    currency: i % 2 === 0 ? "USD" : "INR",
    referralCode: `REF${10000 + rank}`,
    referralCount: Math.floor(Math.random() * 10),
    referralEarningsINR: Math.floor(Math.random() * 5000),
    referralEarningsUSD: Math.floor(Math.random() * 100),
    showEarningsPublicly: Math.random() > 0.3, // 70% chance to show public earnings
    walletINR: { available: 1000, pending: 500 },
    walletUSD: { available: 50, pending: 20 },
    leaderboardRank: rank,
    percentile: Math.min(99, 15 + (i * 0.3)),
    subscriptionTier: ["Beginner", "Professional", "Advanced"][Math.floor(Math.random() * 3)] as SubscriptionTier,
    registrationDate: new Date().toISOString(),
    status: "verified"
  });
}

// Current User Mock - Rank 250
export const CURRENT_USER: User = MOCK_USERS.find(u => u.leaderboardRank === 250) || MOCK_USERS[MOCK_USERS.length - 1];

export const COUNTRIES = [
  "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Argentina", "Armenia", "Australia", "Austria", "Azerbaijan",
  "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bhutan", "Bolivia",
  "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada",
  "India", "United States", "United Kingdom", "Singapore", "Germany", "France", "Japan", "China", "Brazil", "Russia"
  // ... list truncated for brevity but functionality implies 195
];

export const SECTORS = [
  "Fintech", "Healthtech", "Edtech", "SaaS", "E-commerce", "Artificial Intelligence", "Blockchain", "Clean Energy",
  "Logistics", "Manufacturing", "Real Estate", "Retail", "Social Media", "Cybersecurity", "Biotech", "AgriTech",
  "Gaming", "SpaceTech", "Robotics", "IoT"
];

// --- Mock API Functions ---

export const getLeaderboard = async (page = 1, limit = 10, country?: string, sector?: string) => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  let filtered = [...MOCK_USERS];
  
  if (country && country !== "All") {
    filtered = filtered.filter(u => u.country === country);
  }
  
  if (sector && sector !== "All") {
    filtered = filtered.filter(u => u.sector === sector);
  }
  
  // Sort by rank
  filtered.sort((a, b) => a.leaderboardRank - b.leaderboardRank);
  
  const start = (page - 1) * limit;
  const end = start + limit;
  
  return {
    data: filtered.slice(start, end),
    total: filtered.length,
    page,
    totalPages: Math.ceil(filtered.length / limit)
  };
};

export const getLeaderboardContext = async (centerRank: number, range: number = 5) => {
  await new Promise(resolve => setTimeout(resolve, 300));
  const filtered = [...MOCK_USERS].sort((a, b) => a.leaderboardRank - b.leaderboardRank);
  const centerIndex = filtered.findIndex(u => u.leaderboardRank === centerRank);
  
  if (centerIndex === -1) return [];
  
  const start = Math.max(0, centerIndex - range);
  const end = Math.min(filtered.length, centerIndex + range + 1);
  
  return filtered.slice(start, end);
}

export const getUserWallet = async () => {
  await new Promise(resolve => setTimeout(resolve, 300));
  return {
    inr: CURRENT_USER.walletINR,
    usd: CURRENT_USER.walletUSD,
    transactions: [
      { id: "tx1", date: "2025-12-14", type: "Referral Earning", amount: 99.90, currency: "INR", status: "Completed" },
      { id: "tx2", date: "2025-12-13", type: "Referral Earning", amount: 1.50, currency: "USD", status: "Pending" },
      { id: "tx3", date: "2025-12-10", type: "Payment", amount: 999, currency: "INR", status: "Completed" },
    ]
  };
};

export const registerUser = async (userData: any) => {
  await new Promise(resolve => setTimeout(resolve, 1500));
  return {
    success: true,
    message: "Registration successful!",
    userId: "new-user-id",
    referralCode: "REF-NEW-123"
  };
};
