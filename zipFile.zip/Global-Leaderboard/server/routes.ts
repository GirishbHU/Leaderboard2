import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertActivitySchema, insertBlogArticleSchema } from "@shared/schema";
import { createPaypalOrder, capturePaypalOrder, loadPaypalDefault } from "./paypal";
import { 
  createCashfreeOrder, 
  verifyCashfreePayment, 
  getCashfreeOrderStatus, 
  handleCashfreeWebhook, 
  getCashfreeConfig 
} from "./cashfree";
import { processPayment, getPaymentMode, isMockMode } from "./paymentService";
import bcrypt from "bcryptjs";

function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Unauthorized - Please login" });
  }
  next();
}

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Unauthorized - Please login" });
  }
  if (!req.session.isAdmin) {
    return res.status(403).json({ error: "Forbidden - Admin access required" });
  }
  next();
}

function requireActiveSubscription(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Unauthorized - Please login" });
  }
  const status = req.session.subscriptionStatus;
  if (!status || status === "inactive") {
    return res.status(403).json({ error: "Forbidden - Active subscription required" });
  }
  next();
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  await storage.seedDatabase();

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
      }
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      
      const passwordMatch = user.password.startsWith("$2") 
        ? await bcrypt.compare(password, user.password)
        : password === user.password;
        
      if (!passwordMatch) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      
      req.session.userId = user.id;
      req.session.userEmail = user.email;
      req.session.userRole = user.role;
      req.session.isAdmin = user.role === "admin";
      req.session.subscriptionStatus = user.subscriptionStatus;
      
      const { password: _, ...userWithoutPassword } = user;
      res.json({ 
        success: true, 
        user: userWithoutPassword,
        isAdmin: user.role === "admin",
        subscriptionStatus: user.subscriptionStatus,
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.json({ success: true });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.json({ authenticated: false });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.json({ authenticated: false });
    }
    
    const { password: _, ...userWithoutPassword } = user;
    res.json({
      authenticated: true,
      user: userWithoutPassword,
      isAdmin: user.role === "admin",
      subscriptionStatus: user.subscriptionStatus,
    });
  });

  app.post("/api/preview/checkout", requireAuth, async (req, res) => {
    try {
      const { planType, amount, currency } = req.body;
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const paymentResult = await processPayment({
        userId,
        amount: amount || 0,
        currency: currency || user.currency as "INR" | "USD",
        planType: planType || "preview",
        email: user.email,
      });
      
      if (!paymentResult.success) {
        return res.status(400).json({ error: paymentResult.error || "Payment failed" });
      }
      
      await storage.updateUser(userId, {
        subscriptionStatus: "active_preview",
        planType: planType || "preview",
      });
      
      req.session.subscriptionStatus = "active_preview";
      
      res.json({
        success: true,
        orderId: paymentResult.orderId,
        transactionId: paymentResult.transactionId,
        message: paymentResult.message,
        paymentMode: getPaymentMode(),
        isMock: isMockMode(),
      });
    } catch (error) {
      console.error("Preview checkout error:", error);
      res.status(500).json({ error: "Checkout failed" });
    }
  });

  app.get("/api/preview/status", (req, res) => {
    res.json({
      paymentMode: getPaymentMode(),
      isMockMode: isMockMode(),
    });
  });

  app.post("/api/register/preview", async (req, res) => {
    try {
      const { name, email, role, country, sector, currency, displayPreference } = req.body;
      
      if (!name || !email || !role || !country || !sector) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ error: "Email already registered" });
      }
      
      const hashedPassword = await bcrypt.hash("preview123", 10);
      
      const referralCode = `REF-${Date.now().toString(36).toUpperCase()}`;
      const username = email.split("@")[0].toLowerCase().replace(/[^a-z0-9]/g, "") + Math.floor(Math.random() * 1000);
      
      const newUser = await storage.createUser({
        name,
        email,
        password: hashedPassword,
        username,
        role: role || "startup",
        country,
        sector,
        currency: currency || "USD",
        displayPreference: displayPreference || "real_name",
        referralCode,
        subscriptionStatus: "active_preview",
        planType: "preview",
        subscriptionTier: "basic",
        leaderboardRank: 0,
        percentile: 0,
        totalActivityMinutes: 0,
        walletINRAvailable: "0",
        walletINRPending: "0",
        walletUSDAvailable: "0",
        walletUSDPending: "0",
        referredBy: null,
        activityPrivacy: "public_leaderboard",
      });
      
      req.session.userId = newUser.id;
      req.session.userEmail = newUser.email;
      req.session.userRole = newUser.role;
      req.session.isAdmin = false;
      req.session.subscriptionStatus = "active_preview";
      
      const { password: _, ...userWithoutPassword } = newUser;
      
      res.status(201).json({
        success: true,
        message: "Preview registration complete!",
        userId: newUser.id,
        referralCode,
        user: userWithoutPassword,
      });
    } catch (error) {
      console.error("Preview registration error:", error);
      res.status(500).json({ error: "Registration failed" });
    }
  });

  app.get("/api/admin/stats", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getLeaderboard(1, 1000);
      const totalUsers = users.total;
      const activePreview = users.data.filter(u => u.subscriptionStatus === "active_preview").length;
      const admins = users.data.filter(u => u.role === "admin").length;
      
      res.json({
        totalUsers,
        activePreviewUsers: activePreview,
        admins,
        paymentMode: getPaymentMode(),
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch admin stats" });
    }
  });

  app.get("/api/leaderboard", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const country = req.query.country as string;
      const sector = req.query.sector as string;
      
      const result = await storage.getLeaderboard(page, limit, country, sector);
      res.json({
        data: result.data,
        total: result.total,
        page,
        totalPages: Math.ceil(result.total / limit),
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch leaderboard" });
    }
  });

  app.get("/api/leaderboard/context/:rank", async (req, res) => {
    try {
      const rank = parseInt(req.params.rank);
      const range = parseInt(req.query.range as string) || 5;
      const data = await storage.getLeaderboardContext(rank, range);
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch leaderboard context" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  app.get("/api/activities", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 50;
      const filters = {
        category: req.query.category as string,
        country: req.query.country as string,
        sector: req.query.sector as string,
      };
      const result = await storage.getActivities(page, limit, filters);
      res.json({
        data: result.data,
        total: result.total,
        page,
        totalPages: Math.ceil(result.total / limit),
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch activities" });
    }
  });

  app.get("/api/activities/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  app.get("/api/activities/leaderboard", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const leaderboard = await storage.getActivityLeaderboard(page, limit);
      res.json(leaderboard);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch activity leaderboard" });
    }
  });

  app.get("/api/activities/stats", async (req, res) => {
    try {
      const onlyConsented = req.query.consented === "true";
      const stats = await storage.getActivityStats(onlyConsented);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch activity stats" });
    }
  });

  app.get("/api/activities/user/:userId", async (req, res) => {
    try {
      const activities = await storage.getActivitiesByUser(req.params.userId);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user activities" });
    }
  });

  app.post("/api/activities", async (req, res) => {
    try {
      const parsed = insertActivitySchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.message });
      }
      const activity = await storage.createActivity(parsed.data);
      res.status(201).json(activity);
    } catch (error) {
      res.status(500).json({ error: "Failed to create activity" });
    }
  });

  app.get("/api/referrals/:userId", async (req, res) => {
    try {
      const referrals = await storage.getReferrals(req.params.userId);
      res.json(referrals);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch referrals" });
    }
  });

  app.get("/api/transactions/:userId", async (req, res) => {
    try {
      const transactions = await storage.getTransactions(req.params.userId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  app.get("/api/wallet/:userId", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      const transactions = await storage.getTransactions(req.params.userId);
      res.json({
        inr: { available: user.walletINRAvailable, pending: user.walletINRPending },
        usd: { available: user.walletUSDAvailable, pending: user.walletUSDPending },
        transactions,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch wallet" });
    }
  });

  // PayPal Integration Routes
  app.get("/api/paypal/setup", async (req, res) => {
    await loadPaypalDefault(req, res);
  });

  app.post("/api/paypal/order", async (req, res) => {
    await createPaypalOrder(req, res);
  });

  app.post("/api/paypal/order/:orderID/capture", async (req, res) => {
    await capturePaypalOrder(req, res);
  });

  // Cashfree Integration Routes
  app.get("/api/cashfree/config", (req, res) => {
    getCashfreeConfig(req, res);
  });

  app.post("/api/cashfree/order", async (req, res) => {
    await createCashfreeOrder(req, res);
  });

  app.get("/api/cashfree/verify/:orderId", async (req, res) => {
    await verifyCashfreePayment(req, res);
  });

  app.get("/api/cashfree/order/:orderId", async (req, res) => {
    await getCashfreeOrderStatus(req, res);
  });

  app.post("/api/cashfree/webhook", async (req, res) => {
    await handleCashfreeWebhook(req, res);
  });

  // Blog API Routes
  app.get("/api/blog", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const category = req.query.category as string;
      
      const result = await storage.getBlogArticles(page, limit, category);
      res.json({
        data: result.data,
        total: result.total,
        page,
        totalPages: Math.ceil(result.total / limit),
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch blog articles" });
    }
  });

  app.get("/api/blog/featured", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 3;
      const articles = await storage.getFeaturedArticles(limit);
      res.json(articles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch featured articles" });
    }
  });

  app.get("/api/blog/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const article = await storage.getBlogArticle(id);
      if (!article) {
        return res.status(404).json({ error: "Article not found" });
      }
      res.json(article);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch article" });
    }
  });

  app.post("/api/blog", async (req, res) => {
    try {
      const parsed = insertBlogArticleSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.message });
      }
      const article = await storage.createBlogArticle(parsed.data);
      res.status(201).json(article);
    } catch (error) {
      res.status(500).json({ error: "Failed to create article" });
    }
  });

  app.put("/api/blog/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const article = await storage.updateBlogArticle(id, req.body);
      if (!article) {
        return res.status(404).json({ error: "Article not found" });
      }
      res.json(article);
    } catch (error) {
      res.status(500).json({ error: "Failed to update article" });
    }
  });

  app.delete("/api/blog/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteBlogArticle(id);
      if (!deleted) {
        return res.status(404).json({ error: "Article not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete article" });
    }
  });

  return httpServer;
}
