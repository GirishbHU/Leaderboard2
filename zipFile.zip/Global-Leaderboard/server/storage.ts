import { db } from "./db";
import { eq, desc, asc, and, gte, lte, sql, or, ne } from "drizzle-orm";
import bcrypt from "bcryptjs";
import {
  users,
  activityTimeTracking,
  referrals,
  walletTransactions,
  blogArticles,
  type User,
  type InsertUser,
  type Activity,
  type InsertActivity,
  type Referral,
  type InsertReferral,
  type Transaction,
  type InsertTransaction,
  type BlogArticle,
  type InsertBlogArticle,
} from "@shared/schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByReferralCode(code: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined>;
  
  getLeaderboard(page: number, limit: number, country?: string, sector?: string): Promise<{ data: User[]; total: number }>;
  getLeaderboardContext(centerRank: number, range: number): Promise<User[]>;
  
  getActivities(page: number, limit: number, filters?: { category?: string; country?: string; sector?: string }): Promise<{ data: (Activity & { userName?: string; userCountry?: string; userSector?: string })[]; total: number }>;
  getActivitiesByUser(userId: string): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  getActivityStats(onlyConsented?: boolean): Promise<{ category: string; totalMinutes: number; count: number }[]>;
  getActivityLeaderboard(page: number, limit: number): Promise<{ userId: string; userName: string; country: string; sector: string; totalMinutes: number; activityCount: number; privacy: string }[]>;
  getCategories(): Promise<string[]>;
  
  getReferrals(userId: string): Promise<Referral[]>;
  createReferral(referral: InsertReferral): Promise<Referral>;
  
  getTransactions(userId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  getBlogArticles(page?: number, limit?: number, category?: string): Promise<{ data: BlogArticle[]; total: number }>;
  getBlogArticle(id: number): Promise<BlogArticle | undefined>;
  createBlogArticle(article: InsertBlogArticle): Promise<BlogArticle>;
  updateBlogArticle(id: number, data: Partial<InsertBlogArticle>): Promise<BlogArticle | undefined>;
  deleteBlogArticle(id: number): Promise<boolean>;
  getFeaturedArticles(limit?: number): Promise<BlogArticle[]>;
  
  seedDatabase(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserByReferralCode(code: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.referralCode, code));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db.update(users).set(data).where(eq(users.id, id)).returning();
    return user;
  }

  async getLeaderboard(page: number = 1, limit: number = 10, country?: string, sector?: string): Promise<{ data: User[]; total: number }> {
    let query = db.select().from(users);
    
    const conditions = [];
    if (country && country !== "All") {
      conditions.push(eq(users.country, country));
    }
    if (sector && sector !== "All") {
      conditions.push(eq(users.sector, sector));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }

    const offset = (page - 1) * limit;
    const data = await query.orderBy(asc(users.leaderboardRank)).limit(limit).offset(offset);
    
    const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(users);
    
    return { data, total: Number(count) };
  }

  async getLeaderboardContext(centerRank: number, range: number = 5): Promise<User[]> {
    const minRank = Math.max(1, centerRank - range);
    const maxRank = centerRank + range;
    
    return db.select().from(users)
      .where(and(gte(users.leaderboardRank, minRank), lte(users.leaderboardRank, maxRank)))
      .orderBy(asc(users.leaderboardRank));
  }

  async getActivities(page: number = 1, limit: number = 50, filters?: { category?: string; country?: string; sector?: string }): Promise<{ data: (Activity & { userName?: string; userCountry?: string; userSector?: string })[]; total: number }> {
    const offset = (page - 1) * limit;
    
    let query = db.select({
      id: activityTimeTracking.id,
      userId: activityTimeTracking.userId,
      activityName: activityTimeTracking.activityName,
      category: activityTimeTracking.category,
      timeSpentMinutes: activityTimeTracking.timeSpentMinutes,
      date: activityTimeTracking.date,
      description: activityTimeTracking.description,
      userName: users.name,
      userCountry: users.country,
      userSector: users.sector,
    })
      .from(activityTimeTracking)
      .leftJoin(users, eq(activityTimeTracking.userId, users.id));
    
    const conditions = [];
    if (filters?.category && filters.category !== "All") {
      conditions.push(eq(activityTimeTracking.category, filters.category));
    }
    if (filters?.country && filters.country !== "All") {
      conditions.push(eq(users.country, filters.country));
    }
    if (filters?.sector && filters.sector !== "All") {
      conditions.push(eq(users.sector, filters.sector));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }
    
    const data = await query.orderBy(desc(activityTimeTracking.date)).limit(limit).offset(offset);
    
    const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(activityTimeTracking);
    
    return { data, total: Number(count) };
  }

  async getActivitiesByUser(userId: string): Promise<Activity[]> {
    return db.select().from(activityTimeTracking)
      .where(eq(activityTimeTracking.userId, userId))
      .orderBy(desc(activityTimeTracking.date));
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [created] = await db.insert(activityTimeTracking).values(activity).returning();
    return created;
  }

  async getActivityStats(onlyConsented: boolean = false): Promise<{ category: string; totalMinutes: number; count: number }[]> {
    let query = db.select({
      category: activityTimeTracking.category,
      totalMinutes: sql<number>`sum(${activityTimeTracking.timeSpentMinutes})`,
      count: sql<number>`count(*)`,
    })
      .from(activityTimeTracking);
    
    if (onlyConsented) {
      query = query.leftJoin(users, eq(activityTimeTracking.userId, users.id))
        .where(or(eq(users.activityPrivacy, "anonymous_aggregate"), eq(users.activityPrivacy, "public_leaderboard"))) as any;
    }
    
    const stats = await query.groupBy(activityTimeTracking.category);
    
    return stats.map((s: any) => ({
      category: s.category,
      totalMinutes: Number(s.totalMinutes),
      count: Number(s.count),
    }));
  }

  async getActivityLeaderboard(page: number = 1, limit: number = 20): Promise<{ userId: string; userName: string; country: string; sector: string; totalMinutes: number; activityCount: number; privacy: string }[]> {
    const offset = (page - 1) * limit;
    
    const data = await db.select({
      userId: users.id,
      userName: users.name,
      country: users.country,
      sector: users.sector,
      privacy: users.activityPrivacy,
      totalMinutes: sql<number>`sum(${activityTimeTracking.timeSpentMinutes})`,
      activityCount: sql<number>`count(${activityTimeTracking.id})`,
    })
      .from(users)
      .leftJoin(activityTimeTracking, eq(users.id, activityTimeTracking.userId))
      .where(eq(users.activityPrivacy, "public_leaderboard"))
      .groupBy(users.id, users.name, users.country, users.sector, users.activityPrivacy)
      .orderBy(sql`sum(${activityTimeTracking.timeSpentMinutes}) DESC`)
      .limit(limit).offset(offset);
    
    return data.map(d => ({
      userId: d.userId,
      userName: d.userName,
      country: d.country,
      sector: d.sector,
      privacy: d.privacy,
      totalMinutes: Number(d.totalMinutes) || 0,
      activityCount: Number(d.activityCount) || 0,
    }));
  }

  async getCategories(): Promise<string[]> {
    const cats = await db.selectDistinct({ category: activityTimeTracking.category }).from(activityTimeTracking);
    return cats.map(c => c.category);
  }

  async getReferrals(userId: string): Promise<Referral[]> {
    return db.select().from(referrals)
      .where(eq(referrals.referrerId, userId))
      .orderBy(desc(referrals.createdAt));
  }

  async createReferral(referral: InsertReferral): Promise<Referral> {
    const [created] = await db.insert(referrals).values(referral).returning();
    return created;
  }

  async getTransactions(userId: string): Promise<Transaction[]> {
    return db.select().from(walletTransactions)
      .where(eq(walletTransactions.userId, userId))
      .orderBy(desc(walletTransactions.createdAt));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [created] = await db.insert(walletTransactions).values(transaction).returning();
    return created;
  }

  async getBlogArticles(page: number = 1, limit: number = 20, category?: string): Promise<{ data: BlogArticle[]; total: number }> {
    const offset = (page - 1) * limit;
    
    let query = db.select().from(blogArticles);
    let countQuery = db.select({ count: sql<number>`count(*)` }).from(blogArticles);
    
    if (category && category !== "All") {
      query = query.where(eq(blogArticles.category, category)) as any;
      countQuery = countQuery.where(eq(blogArticles.category, category)) as any;
    }
    
    const data = await query.orderBy(desc(blogArticles.publishedDate)).limit(limit).offset(offset);
    const [{ count }] = await countQuery;
    
    return { data, total: Number(count) };
  }

  async getBlogArticle(id: number): Promise<BlogArticle | undefined> {
    const [article] = await db.select().from(blogArticles).where(eq(blogArticles.id, id));
    return article;
  }

  async createBlogArticle(article: InsertBlogArticle): Promise<BlogArticle> {
    const [created] = await db.insert(blogArticles).values(article).returning();
    return created;
  }

  async updateBlogArticle(id: number, data: Partial<InsertBlogArticle>): Promise<BlogArticle | undefined> {
    const [updated] = await db.update(blogArticles).set(data).where(eq(blogArticles.id, id)).returning();
    return updated;
  }

  async deleteBlogArticle(id: number): Promise<boolean> {
    const result = await db.delete(blogArticles).where(eq(blogArticles.id, id)).returning();
    return result.length > 0;
  }

  async getFeaturedArticles(limit: number = 3): Promise<BlogArticle[]> {
    return db.select().from(blogArticles)
      .where(eq(blogArticles.featured, true))
      .orderBy(desc(blogArticles.publishedDate))
      .limit(limit);
  }

  async seedDatabase(): Promise<void> {
    const adminEmail = "admin@example.com";
    const existingAdmin = await this.getUserByEmail(adminEmail);
    
    if (!existingAdmin) {
      const hashedPassword = await bcrypt.hash("AdminTest123!", 10);
      await db.insert(users).values({
        email: adminEmail,
        name: "Admin User",
        username: "admin",
        password: hashedPassword,
        role: "admin",
        country: "Global",
        sector: "Platform",
        currency: "USD",
        displayPreference: "real_name",
        referralCode: "ADMIN001",
        referralCount: 0,
        referralEarningsINR: 0,
        referralEarningsUSD: 0,
        showEarningsPublicly: false,
        walletINRAvailable: 0,
        walletINRPending: 0,
        walletUSDAvailable: 0,
        walletUSDPending: 0,
        leaderboardRank: 0,
        percentile: 100,
        subscriptionTier: "Pro Max Ultra",
        status: "verified",
        subscriptionStatus: "active_preview",
        planType: "enterprise",
      });
      console.log("Admin user seeded: admin@example.com / AdminTest123!");
    }
    
    const existingUsers = await db.select({ count: sql<number>`count(*)` }).from(users);
    if (Number(existingUsers[0].count) > 1) {
      return;
    }

    const countries = ["USA", "India", "UK", "Germany", "France", "Japan", "Brazil", "Canada", "Australia", "Singapore", "Vietnam", "Armenia", "Hungary", "Qatar", "Bahrain", "Lebanon"];
    const sectors = ["Fintech", "Healthtech", "Edtech", "SaaS", "E-commerce", "AI", "Clean Energy", "Parking & Mobility", "Tax Planning", "Smart Home & IoT", "Enterprise Software", "Language Learning", "Logistics", "Government Tech", "Shipping & Freight"];
    const roles = ["startup", "investor", "enabler", "professional", "influencer", "accelerator", "ngo", "vc", "government", "mentor"];
    const tiers = ["Beginner", "Professional", "Advanced", "Pro Max Ultra"];
    const activities = [
      { name: "Platform Onboarding", category: "Setup" },
      { name: "Profile Completion", category: "Setup" },
      { name: "Pitch Deck Upload", category: "Content" },
      { name: "Investor Meeting", category: "Networking" },
      { name: "Webinar Attendance", category: "Learning" },
      { name: "Mentor Session", category: "Networking" },
      { name: "Document Review", category: "Admin" },
      { name: "Team Collaboration", category: "Work" },
      { name: "Market Research", category: "Research" },
      { name: "Product Demo", category: "Sales" },
      { name: "Funding Application", category: "Finance" },
      { name: "Compliance Check", category: "Admin" },
      { name: "Partnership Discussion", category: "Networking" },
      { name: "Strategy Planning", category: "Planning" },
      { name: "Customer Interview", category: "Research" },
    ];

    const usersToInsert: InsertUser[] = [];
    for (let i = 1; i <= 350; i++) {
      usersToInsert.push({
        email: `user${i}@i2u.ai`,
        name: `User ${i}`,
        username: `user_${i}`,
        password: "hashed_password_placeholder",
        role: roles[Math.floor(Math.random() * roles.length)],
        country: countries[Math.floor(Math.random() * countries.length)],
        sector: sectors[Math.floor(Math.random() * sectors.length)],
        currency: i % 2 === 0 ? "USD" : "INR",
        displayPreference: "real_name",
        companyName: i % 3 === 0 ? `Company ${i}` : null,
        startupStage: i % 4 === 0 ? ["Idea", "Pre-seed", "Seed", "Series A", "Series B"][Math.floor(Math.random() * 5)] : null,
        referralCode: `REF${10000 + i}`,
        referralCount: Math.floor(Math.random() * 50),
        referralEarningsINR: Math.floor(Math.random() * 10000),
        referralEarningsUSD: Math.floor(Math.random() * 200),
        showEarningsPublicly: Math.random() > 0.3,
        walletINRAvailable: Math.floor(Math.random() * 5000),
        walletINRPending: Math.floor(Math.random() * 1000),
        walletUSDAvailable: Math.floor(Math.random() * 100),
        walletUSDPending: Math.floor(Math.random() * 50),
        leaderboardRank: i,
        percentile: Math.min(99.9, (i / 350) * 100),
        subscriptionTier: tiers[Math.floor(Math.random() * tiers.length)],
        status: Math.random() > 0.2 ? "verified" : "pending",
      });
    }

    await db.insert(users).values(usersToInsert);

    const insertedUsers = await db.select({ id: users.id }).from(users);
    
    const activitiesToInsert: InsertActivity[] = [];
    for (let i = 0; i < 350; i++) {
      const activity = activities[Math.floor(Math.random() * activities.length)];
      const randomUser = insertedUsers[Math.floor(Math.random() * insertedUsers.length)];
      activitiesToInsert.push({
        userId: randomUser.id,
        activityName: activity.name,
        category: activity.category,
        timeSpentMinutes: Math.floor(Math.random() * 180) + 15,
        description: `${activity.name} session completed`,
      });
    }

    await db.insert(activityTimeTracking).values(activitiesToInsert);
  }
}

export const storage = new DatabaseStorage();
