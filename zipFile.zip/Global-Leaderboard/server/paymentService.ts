const PAYMENTS_MODE = process.env.PAYMENTS_MODE || "mock";

export interface PaymentResult {
  success: boolean;
  orderId?: string;
  transactionId?: string;
  message?: string;
  error?: string;
}

export interface PaymentRequest {
  userId: string;
  amount: number;
  currency: "INR" | "USD";
  planType: string;
  email: string;
}

export async function processPayment(request: PaymentRequest): Promise<PaymentResult> {
  if (PAYMENTS_MODE === "mock") {
    return mockPayment(request);
  }
  
  if (PAYMENTS_MODE === "sandbox") {
    return sandboxPayment(request);
  }
  
  if (PAYMENTS_MODE === "live") {
    return livePayment(request);
  }
  
  return { success: false, error: "Invalid payment mode" };
}

async function mockPayment(request: PaymentRequest): Promise<PaymentResult> {
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const mockOrderId = `MOCK-${Date.now()}-${Math.random().toString(36).substring(7)}`;
  const mockTransactionId = `TXN-${Date.now()}`;
  
  return {
    success: true,
    orderId: mockOrderId,
    transactionId: mockTransactionId,
    message: `Mock payment successful for ${request.planType} plan (${request.currency} ${request.amount})`,
  };
}

async function sandboxPayment(request: PaymentRequest): Promise<PaymentResult> {
  return {
    success: true,
    orderId: `SANDBOX-${Date.now()}`,
    transactionId: `SANDBOX-TXN-${Date.now()}`,
    message: "Sandbox payment processed",
  };
}

async function livePayment(request: PaymentRequest): Promise<PaymentResult> {
  return {
    success: false,
    error: "Live payments not yet implemented",
  };
}

export function getPaymentMode(): string {
  return PAYMENTS_MODE;
}

export function isMockMode(): boolean {
  return PAYMENTS_MODE === "mock";
}
